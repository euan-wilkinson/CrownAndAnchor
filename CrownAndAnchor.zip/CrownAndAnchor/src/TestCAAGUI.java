
public class TestCAAGUI {

	public static void main(String[] args) {
		CrownAndAnchorGUI test = new CrownAndAnchorGUI();
	}
}